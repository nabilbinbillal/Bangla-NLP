# BanglaNLP v0.1

**BanglaNLP** is a free, open-source Python toolkit for **Bengali Natural Language Processing (Bangla NLP)**. It provides essential NLP functionalities for Bangla, designed to work **offline with editable datasets**, making it beginner-friendly and easy to extend.

Whether you are building **Bangla chatbots, text analysis tools, sentiment classifiers, or research projects**, BanglaNLP provides a modular foundation.

---

## 🔹 Features

- **Tokenization:** Split Bangla text into individual words.
- **Stopword Removal:** Remove common Bangla stopwords for clean text.
- **POS Tagging (Offline):** Rule-based part-of-speech tagging (NOUN, VERB, unknown).
- **Named Entity Recognition (NER, Offline):** Detect names, locations, and organizations using simple word lists.
- **Sentiment Analysis (Offline):** Classify Bangla text as positive, negative, or neutral using keyword-based scoring.
- **Editable Datasets:** All stopwords, names, locations, organizations, and sentiment words are stored in `datasets/` and can be customized.
- **Example Scripts:** `examples/hello_bangla.py` demonstrates all features.
- **Modular & Expandable:** Designed to allow future integration of pretrained models (BanglaBERT, Hugging Face) and additional NLP features.

---

## 🔹 Installation

Clone the repository and install the package in **editable mode**:

```bash
git clone https://github.com/nabilbinbillal/Bangla-NLP.git
cd Bangla-NLP
pip install -e .
```

You can now import `banglanlp` in any Python file within your virtual environment.

---

## 🔹 Datasets / Editable Resources

All datasets are stored in the `datasets/` folder:

- `stopwords.txt` – Common Bangla stopwords
- `names.txt` – Person names (male & female)
- `locations.txt` – Cities, towns, or places in Bangladesh
- `organizations.txt` – Institutions or organizations
- `positive_words.txt` – Positive sentiment words
- `negative_words.txt` – Negative sentiment words

All datasets are editable to improve NLP results.

---

## 🔹 Quick Start / Full Usage Example

Get started with BanglaNLP in just a few lines of Python. This example demonstrates tokenization, stopword removal, POS tagging, NER, and sentiment analysis.

```python
from banglanlp.tokenization import tokenize
from banglanlp.stopwords import remove_stopwords
from banglanlp.pos import pos_tag
from banglanlp.ner import ner_tag
from banglanlp.sentiment import sentiment_analysis

# Sample Bangla text
text = "রবীন্দ্রনাথ ঢাকায় গান গাইলেন। আজ আবহাওয়া খুব সুন্দর।"

# Step 1: Tokenization
tokens = tokenize(text)
print("Tokens:", tokens)

# Step 2: Stopword Removal
filtered = remove_stopwords(tokens)
print("After stopword removal:", filtered)

# Step 3: POS Tagging
pos_results = pos_tag(filtered)
print("POS tagging:", pos_results)

# Step 4: Named Entity Recognition (NER)
ner_results = ner_tag(filtered)
print("NER tagging:", ner_results)

# Step 5: Sentiment Analysis
sentiment = sentiment_analysis(filtered)
print("Sentiment:", sentiment)
```

### Sample Output

```pgsql
Tokens: ['রবীন্দ্রনাথ', 'ঢাকায়', 'গান', 'গাইলেন', 'আজ', 'আবহাওয়া', 'খুব', 'সুন্দর']
After stopword removal: ['রবীন্দ্রনাথ', 'ঢাকায়', 'গান', 'গাইলেন', 'আজ', 'আবহাওয়া', 'খুব', 'সুন্দর']
POS tagging: [('রবীন্দ্রনাথ', 'NOUN'), ('ঢাকায়', 'X'), ('গান', 'X'), ('গাইলেন', 'VERB'), ('আজ', 'X'), ('আবহাওয়া', 'X'), ('খুব', 'X'), ('সুন্দর', 'X')]
NER tagging: [('রবীন্দ্রনাথ', 'NAME'), ('ঢাকায়', 'LOCATION'), ('গান', 'O'), ('গাইলেন', 'O'), ('আজ', 'O'), ('আবহাওয়া', 'O'), ('খুব', 'O'), ('সুন্দর', 'O')]
Sentiment: POSITIVE
```

This script can also be run directly from the `examples/` folder with:

```bash
python3 -m examples.hello_bangla
```

---

## 🔹 Contribution

We welcome contributions to improve BanglaNLP:

- Add advanced POS tagging or NER categories
- Integrate pretrained models like BanglaBERT
- Add text summarization, translation, or speech modules
- Improve datasets with more words, names, and locations

Fork the repo, make changes, and submit pull requests.

---

## 🔹 License

MIT License – Free to use, modify, and distribute for personal, educational, or commercial projects.

---

## 🔹 Roadmap / Next Versions

- Pretrained Bangla embeddings integration (BanglaBERT, Transformers)
- Advanced POS & NER using ML models
- Bangla text summarization and translation
- Speech-to-text and text-to-speech for Bangla
- Sentiment analysis improvement using ML models

---

## 🔹 SEO Optimized Keywords

BanglaNLP, Bangla NLP, Bengali NLP toolkit, Bangla text processing, Bangla sentiment analysis, Bangla POS tagging, Bangla NER, Bangla tokenization, Bengali language processing, Bangla Python library, Bangla datasets, Open-source Bangla NLP, Free Bangla NLP tools

---

BanglaNLP v0.1 is your free, offline, beginner-friendly toolkit for Bengali NLP, fully modular, editable, and ready for research or real-world projects.
